/************************************************************************/
/*																		*/
/*	dma_to_sd.c	--	Zybo DMA to SD Card Program	 						*/
/*																		*/
/*	Author: Ryan M. Corey, University of Illinois						*/
/*  Created: 9/30/2017													*/
/*																		*/
/*		Transfers data from a peripheral to memory using DMA, then		*/
/*		writes the data to the microSD card								*/
/*																		*/
/************************************************************************/


#include "demo.h"

#include "audio/audio.h"
#include "dma/dma.h"
#include "intc/intc.h"
#include "userio/userio.h"
#include "iic/iic.h"

/***************************** Include Files *********************************/

#include "xaxidma.h"
#include "xparameters.h"
#include "xil_exception.h"
#include "xdebug.h"
#include "xiic.h"
#include "xaxidma.h"
#include "xtime_l.h"


#ifdef XPAR_INTC_0_DEVICE_ID
 #include "xintc.h"
#else
 #include "xscugic.h"
#include "sleep.h"
#include "xil_cache.h"
#endif

#include "ff.h"

/************************** Constant Definitions *****************************/

/*
 * Device hardware build related constants.
 */

// Audio constants
#define AUDIO_SAMPLING_RATE	  	(96000)	// Samples per second - MUST CHANGE REGISTERS IN AUDIO.C
#define SAMPLES_PER_FRAME		(1024)	// Must be a multiple of 512
#define MAX_FRAMES				(1024*1024)	// Roughly 4 GB
// Note: this program doesn't need to know the number of channels
// It just takes as many samples as it's given and writes them to disk


/* Timeout loop counter for reset
 */
#define RESET_TIMEOUT_COUNTER	(10000)

#define TEST_START_VALUE	(0x0)


/**************************** Type Definitions *******************************/


/***************** Macros (Inline Functions) Definitions *********************/


/************************** Function Prototypes ******************************/
#if (!defined(DEBUG))
extern void xil_printf(const char *format, ...);
#endif


/************************** Variable Definitions *****************************/
/*
 * Device instance definitions
 */

static XIic sIic;
static XAxiDma sAxiDma;		/* Instance of the XAxiDma */

static XGpio sUserIO;
static XGpio sGpioSwitches;

#ifdef XPAR_INTC_0_DEVICE_ID
 static XIntc sIntc;
#else
 static XScuGic sIntc;
#endif

//
// Interrupt vector table
#ifdef XPAR_INTC_0_DEVICE_ID
const ivt_t ivt[] = {
	//IIC
	{XPAR_AXI_INTC_0_AXI_IIC_0_IIC2INTC_IRPT_INTR, (XInterruptHandler)XIic_InterruptHandler, &sIic},
	//DMA Stream to MemoryMap Interrupt handler
	{XPAR_AXI_INTC_0_AXI_DMA_0_S2MM_INTROUT_INTR, (XInterruptHandler)fnS2MMInterruptHandler, &sAxiDma},
	//DMA MemoryMap to Stream Interrupt handler
	{XPAR_AXI_INTC_0_AXI_DMA_0_MM2S_INTROUT_INTR, (XInterruptHandler)fnMM2SInterruptHandler, &sAxiDma},
	//User I/O (buttons, switches, LEDs)
	{XPAR_AXI_INTC_0_AXI_GPIO_0_IP2INTC_IRPT_INTR, (XInterruptHandler)fnUserIOIsr, &sUserIO}
};
#else
const ivt_t ivt[] = {
	//IIC
	{XPAR_FABRIC_AXI_IIC_0_IIC2INTC_IRPT_INTR, (Xil_ExceptionHandler)XIic_InterruptHandler, &sIic},
	//DMA Stream to MemoryMap Interrupt handler
	{XPAR_FABRIC_AXI_DMA_0_S2MM_INTROUT_INTR, (Xil_ExceptionHandler)fnS2MMInterruptHandler, &sAxiDma},
	//DMA MemoryMap to Stream Interrupt handler
	{XPAR_FABRIC_AXI_DMA_0_MM2S_INTROUT_INTR, (Xil_ExceptionHandler)fnMM2SInterruptHandler, &sAxiDma},
	//User I/O (buttons, switches, LEDs)
	{XPAR_FABRIC_AXI_GPIO_0_IP2INTC_IRPT_INTR, (Xil_ExceptionHandler)fnUserIOIsr, &sUserIO}
};
#endif

static const char FileName[32] = "out.dat";


/*****************************************************************************/
/**
*
* Main function
*
* This function is the main entry of the interrupt test. It does the following:
*	Initialize the interrupt controller
*	Initialize the IIC controller
*	Initialize the User I/O driver
*	Initialize the DMA engine
*	Initialize the Audio I2S controller
*	Enable the interrupts
*	Wait for a button event then start selected task
*	Wait for task to complete
*
* @param	None
*
* @return
*		- XST_SUCCESS if example finishes successfully
*		- XST_FAILURE if example fails.
*
* @note		None.
*
******************************************************************************/
int main(void)
{
	int Status;		// Return value from functions that can succeed or fail
	FRESULT Res;	// Return value from file I/O functions
	UINT NumBytesWritten;
	u32 num_transfers = 0;
	union ubitField uTransferVariable;
	FIL fil;
	FATFS fatfs;
	u32 dwSw;

	Demo.u8Verbose = 1;

	xil_printf("\r\n--- Entering main() --- \r\n");

	//Initialize the interrupt controller
	Status = fnInitInterruptController(&sIntc);
	if(Status != XST_SUCCESS) {
		xil_printf("Error initializing interrupts");
		return XST_FAILURE;
	}

	// Initialize IIC controller
	Status = fnInitIic(&sIic);
	if(Status != XST_SUCCESS) {
		xil_printf("Error initializing I2C controller");
		return XST_FAILURE;
	}

    // Initialize User I/O driver
    Status = fnInitUserIO(&sUserIO);
    if(Status != XST_SUCCESS) {
    	xil_printf("User I/O ERROR");
    	return XST_FAILURE;
    }
    XGpio_Initialize(&sGpioSwitches, 1);
	XGpio_SetDataDirection(&sGpioSwitches, 1, 0xF);

	//Initialize DMA
	Status = fnConfigDma(&sAxiDma);
	if(Status != XST_SUCCESS) {
		xil_printf("DMA configuration ERROR");
		return XST_FAILURE;
	}

	//Initialize Audio I2S
	Status = fnInitAudio();
	if(Status != XST_SUCCESS) {
		xil_printf("Audio initializing ERROR");
		return XST_FAILURE;
	}

	{
		XTime  tStart, tEnd;

		XTime_GetTime(&tStart);
		do {
			XTime_GetTime(&tEnd);
		}
		while((tEnd-tStart)/(COUNTS_PER_SECOND/10) < 20);
	}
	//Initialize Audio I2S
	Status = fnInitAudio();
	if(Status != XST_SUCCESS) {
		xil_printf("Audio initializing ERROR");
		return XST_FAILURE;
	}

	// Mount file system
	Res = f_mount(&fatfs, "0:/",0);
	if(Res != FR_OK) {
		xil_printf("File mounting ERROR");
		return XST_FAILURE;
	}

	// Enable all interrupts in our interrupt vector table
	// Make sure all driver instances using interrupts are initialized first
	fnEnableInterrupts(&sIntc, &ivt[0], sizeof(ivt)/sizeof(ivt[0]));

	xil_printf("----------------------------------------------------------\r\n");
	xil_printf("Zybo DMA to SD Utility\r\n");
	xil_printf("----------------------------------------------------------\r\n");

    //main loop

    while(1) {

		// Checking the DMA S2MM event flag (recording complete)
		if (Demo.fDmaS2MMEvent)
		{
			//xil_printf("Transfer %d complete...\r\n",num_transfers);
			Demo.fDmaS2MMEvent = 0;
			num_transfers++;


			// Disable Stream function to send data (S2MM)
			Xil_Out32(I2S_STREAM_CONTROL_REG, 0x00000000);
			Xil_Out32(I2S_STREAM_CONTROL_REG_1, 0x00000000);
			Xil_Out32(I2S_STREAM_CONTROL_REG_2, 0x00000000);
			Xil_Out32(I2S_STREAM_CONTROL_REG_3, 0x00000000);

			// Something to do with DMA and cache coherence?
			Xil_DCacheInvalidateRange((u32) MEM_BASE_ADDR, 20*SAMPLES_PER_FRAME);

			// Start new transfer
			if (Demo.fAudioRecord)
			{
				//xil_printf("Recording frame %d...\r\n",num_transfers);

				uTransferVariable.l = XAxiDma_SimpleTransfer(&sAxiDma,(u32) MEM_BASE_ADDR, 20*((u32)SAMPLES_PER_FRAME), XAXIDMA_DEVICE_TO_DMA);
				if (uTransferVariable.l != XST_SUCCESS) {
					xil_printf("\n fail @ rec; ERROR: %d", uTransferVariable.l);
				}

				// Enable Stream function to send data (S2MM)
				Xil_Out32(I2S_STREAM_CONTROL_REG, 0x00000001);
				Xil_Out32(I2S_STREAM_CONTROL_REG_1, 0x00000001);
				Xil_Out32(I2S_STREAM_CONTROL_REG_2, 0x00000001);
				Xil_Out32(I2S_STREAM_CONTROL_REG_3, 0x00000001);
			}

			// Write to file
			Res = f_write(&fil, (u32) (MEM_BASE_ADDR), 16*SAMPLES_PER_FRAME,&NumBytesWritten);
			if(Res != FR_OK) {
				xil_printf("File writing ERROR");
				return XST_FAILURE;
			}

			// Toggle LED to show recording status
			XGpio_DiscreteWrite(&sUserIO,LED_CHANNEL,(num_transfers >> 4) & 1);

			// End recording
			if (!Demo.fAudioRecord)
			{
				if (Demo.u8Verbose)
					xil_printf("Recording complete. Saving file...\r\n");

				// Close file
				Res = f_close(&fil);
				if(Res != FR_OK) {
					xil_printf("File closing ERROR");
					return XST_FAILURE;
				}

				// Disable stream transfer
				Xil_Out32(I2S_TRANSFER_CONTROL_REG, 0x00000000);
				Xil_Out32(I2S_TRANSFER_CONTROL_REG_1, 0x00000000);
				Xil_Out32(I2S_TRANSFER_CONTROL_REG_2, 0x00000000);
				Xil_Out32(I2S_TRANSFER_CONTROL_REG_3, 0x00000000);

				xil_printf("Recording saved!\r\n");
				XGpio_DiscreteWrite(&sUserIO,LED_CHANNEL,0);
			}
		}

		// Checking the DMA MM2S event flag (playback)
		if (Demo.fDmaMM2SEvent)
		{
			xil_printf("\r\nPlayback Done...");

			// Disable Stream function to send data (S2MM)
			Xil_Out32(I2S_STREAM_CONTROL_REG, 0x00000000);
			Xil_Out32(I2S_TRANSFER_CONTROL_REG, 0x00000000);
			//Flush cache
			Xil_DCacheFlushRange((u32) MEM_BASE_ADDR, 5*SAMPLES_PER_FRAME);
			//Reset MM2S event and playback flag
			Demo.fDmaMM2SEvent = 0;
			Demo.fAudioPlayback = 0;
		}

		// Checking the DMA Error event flag
		if (Demo.fDmaError)
		{
			xil_printf("\r\nDma Error...");
			xil_printf("\r\nDma Reset...");

			Demo.fDmaError = 0;
			Demo.fAudioPlayback = 0;
			Demo.fAudioRecord = 0;
		}

		// Checking the btn change event
		if(Demo.fUserIOEvent) {

			switch(Demo.chBtn) {
				case 'r':
					if (!Demo.fAudioRecord)
					{
						xil_printf("\r\nStart Recording...\r\n");

						// Choose source
						dwSw = XGpio_DiscreteRead(&sGpioSwitches, 1);
						if (dwSw & 1)
						{
							fnSetMicInput();
						} else {
							fnSetLineInput();
						}

						// Open file for recording
						Res = f_open(&fil, (char*)FileName, FA_CREATE_ALWAYS | FA_WRITE | FA_READ);
						if(Res != FR_OK) {
							xil_printf("File opening ERROR");
							return XST_FAILURE;
						}
						num_transfers = 0;

						// Start recording
						fnAudioRecord(sAxiDma,(u32)SAMPLES_PER_FRAME);
						Demo.fAudioRecord = 1;
					}
					break;
				case 'l':
					xil_printf("Stopping recording...\r\n");
					Demo.fAudioRecord = 0;
				default:
					break;
			}

			// Reset the user I/O flag
			Demo.chBtn = 0;
			Demo.fUserIOEvent = 0;
		}

		// Stop recording to prevent a giant file
		if (Demo.fAudioRecord && (num_transfers >= ((u32)MAX_FRAMES)))
		{
			xil_printf("Maximum file size reached! Stopping recording...\r\n");
			Demo.fAudioRecord = 0;
		}

    }

	xil_printf("\r\n--- Exiting main() --- \r\n");


	return XST_SUCCESS;

}









